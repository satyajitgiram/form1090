
SCOPES = ['https://www.googleapis.com/auth/spreadsheets']
SHEET_NAME = 'STUDENTS'
SAMPLE_SPREADSHEET_ID='1KvNOLBRAhCBDo-cgZUsh4XnBZDAdfDC4MqqdqSwZedE'
SERVICE_ACCOUNT_FILE = 'talmud-350506-bcde3688cfc5.json'
